package com.example.listview;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import java.util.ArrayList;



public class MainActivity extends AppCompatActivity {

    ListView listView;
    Button addButton;
    EditText editTextItem;

    ArrayList<String> listItems;
    ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.listView);
        addButton = findViewById(R.id.addButton);
        editTextItem = findViewById(R.id.editTextItem);

        // Initialize the ArrayList and Adapter
        listItems = new ArrayList<>();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, listItems);

        // Set the adapter to the ListView
        listView.setAdapter(adapter);
// Set an OnClickListener for the button to add items from user input



        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get the user input from EditText
                String newItem = editTextItem.getText().toString();

                // Check if input is not empty
                if (!newItem.isEmpty()) {
                    // Add the new item to the ArrayList
                    listItems.add(newItem);

                    // Notify the adapter to update the ListView
                    adapter.notifyDataSetChanged();

                    // Clear the input field for the next entry
                    editTextItem.setText("");
                } else {
                    // Show a message if the input is empty
                    Toast.makeText(MainActivity.this, "Please enter an item", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}

